---
name: AI Event Manager Custom Template
about: Custom template for Bill Gates' Sons Team.
title: ''
labels: ''
assignees: ''

---

---
name: 'Task Card'
about: 'A standard task for the hackathon project'
title: '[AREA]: Short, descriptive title'
labels: 'Phase 1: Foundation'
assignees: ''

---

### 🎯 Goal
A single, clear sentence describing the objective of this task.

### ✅ Acceptance Criteria
- [ ] A specific, measurable outcome that proves this task is complete.
- [ ] Another specific outcome.
- [ ] A third specific outcome.

### 🔗 Dependencies
- (Optional) Link to any other issues that must be completed first (e.g., "Blocks #5").
